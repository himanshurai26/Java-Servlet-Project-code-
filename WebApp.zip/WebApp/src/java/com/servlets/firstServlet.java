
package com.servlets;
import javax.servlet.*;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

public class firstServlet implements Servlet {
 // Life cycle methods
    
    ServletConfig conf;
    
    public void init(ServletConfig conf)
    {
        this.conf=conf;
        System.out.println("Creating Objects.......");
   
    }
    
    public void service(ServletRequest req,ServletResponse resp)throws ServletException,IOException
    {
        
    System.out.println("Servicing........");
    // set the content type of the response
    resp.setContentType("text/html");
    PrintWriter out = resp.getWriter();
    out.println("<h1>this is my output from servlet method</h1>");
    out.println("</h1>" + "<h1>Today date and time us </h1>" + new Date().toString());
    }
  
  public void desstroy(){
      System.out.println("Destroying........");
  }
    // Non Life cycle
  
  public ServletConfig getServletConfig(){
      return this.conf;
  }
  
  public String getServletInfo()
  {
      return("Created by Himanshu Kumar");
      //  return null;
  }

    @Override
    public void destroy() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    }
